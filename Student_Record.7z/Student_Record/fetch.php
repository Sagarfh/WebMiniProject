<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/student.css">
    <title>Result</title>
</head>
<body>
<?php
	include("init.php");
    //include("session.php");

    if(!isset($_GET['rn']))
            $rn=null;
    else
            $rn=$_GET['rn'];

    // validation
        if (empty($rn)) {
                echo '<p class="error">Please enter your Roll no.</p>';
        }
       

    $cgpa_sql=mysqli_query($conn,"SELECT `name` FROM `cgpa` WHERE `rno`='$rn'");
        while($row = mysqli_fetch_assoc($cgpa_sql))
        {
        $name = $row['name'];
        }

    $result_sql=mysqli_query($conn,"SELECT `c1`, `c2`, `c3`,`c4`, `c5`, `c6`,`c7`, `c8`,`cgpa` FROM `cgpa` WHERE `rno`='$rn'");
        while($row = mysqli_fetch_assoc($result_sql))
        {
            $c1 = $row['c1'];
            $c2 = $row['c2'];
            $c3 = $row['c3'];
            $c4 = $row['c4'];
            $c5 = $row['c5'];
            $c6 = $row['c6'];
            $c7 = $row['c7'];
            $c8 = $row['c8'];
            $cgpa = $row['cgpa'];
        }
        if(mysqli_num_rows($result_sql)==0){
            echo "no result";
            exit();
        }
?>

<div class="container">
        <div class="details">
            <span>Name:</span> <?php echo $name ?> <br>
            <span>Roll No:</span> <?php echo $rn; ?> <br>
        </div>

        <div class="main">
            <div class="s1">
                <p>Semester</p>
                <p>SEM 1</p>
                <p>SEM 2</p>
                <p>SEM 3</p>
                <p>SEM 4</p>
                <p>SEM 5</p>
                <p>SEM 6</p>
                <p>SEM 7</p>
                <p>SEM 8</p>
            </div>
            <div class="s2">
                <p>SGPA</p>
                <?php echo '<p>'.$c1.'</p>';?>
                <?php echo '<p>'.$c2.'</p>';?>
                <?php echo '<p>'.$c3.'</p>';?>
                <?php echo '<p>'.$c4.'</p>';?>
                <?php echo '<p>'.$c5.'</p>';?>
                <?php echo '<p>'.$c6.'</p>';?>
                <?php echo '<p>'.$c7.'</p>';?>
                <?php echo '<p>'.$c8.'</p>';?>              
            </div>
        </div>

        <div class="result">
           
            <?php echo '<p>CGPA:&nbsp'.$cgpa.'</p>';?>
        </div>

        <div class="button">
            <button onclick="window.print()">Print Result</button>
        </div>
    </div>
</body>
</html>