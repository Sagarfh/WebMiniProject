<?php
    include("init.php");
    include("session.php");

     if(isset($_POST['name'],$_POST['rno'],$_POST['c1'],$_POST['c2'],$_POST['c3'],$_POST['c4'],$_POST['c5'],$_POST['c6'],$_POST['c7'],$_POST['c8']))
     {
        $name=$_POST['name'];
        $rno=$_POST['rno'];
        $c1=(float)$_POST['c1'];
        $c2=(float)$_POST['c2'];
        $c3=(float)$_POST['c3'];
        $c4=(float)$_POST['c4'];
        $c5=(float)$_POST['c5'];
        $c6=(float)$_POST['c6'];
        $c7=(float)$_POST['c7'];
        $c8=(float)$_POST['c8'];

        $cg=(($c1+$c2+$c3+$c4+$c5+$c6+$c7+$c8)/8);


        // validation
        if (empty($name) or empty($rno)) {
            if(empty($name))
                echo '<p class="error">Please enter name</p>';
            if(empty($rno))
                echo '<p class="error">Please enter roll number</p>';
            if(preg_match("/[a-z]/i",$c1))
                echo '<p class="error">Please enter valid marks</p>';
            if(preg_match("/[a-z]/i",$c2))
                echo '<p class="error">Please enter valid marks</p>';
            if(preg_match("/[a-z]/i",$c3))
                echo '<p class="error">Please enter valid marks</p>';
            if(preg_match("/[a-z]/i",$c4))
                echo '<p class="error">Please enter valid marks</p>';
            if(preg_match("/[a-z]/i",$c5))
                echo '<p class="error">Please enter valid marks</p>';
            if(preg_match("/[a-z]/i",$c6))
                echo '<p class="error">Please enter valid marks</p>';
            if(preg_match("/[a-z]/i",$c7))
                echo '<p class="error">Please enter valid marks</p>';
            if(preg_match("/[a-z]/i",$c8))
                echo '<p class="error">Please enter valid marks</p>';
            #if($c1>10 or  $c2>10 or $c3>10 or $c4>10 or  $c5>10 or $c6>10 or $c7>10 or  $c8>10 or  $c1<0.1 or  $c2<0.1 or $c3<0.1 or $c4<0.1 or $c5<0.1 or $c6<0.1 or $c7<0.1 or $c8<0.1)
            #    echo '<p class="error">Please enter valid marks</p>';
            
            exit();
        }

        $sql="INSERT INTO `cgpa` (`name`, `rno`, `c1`, `c2`, `c3`, `c4`, `c5`, `c6`, `c7`, `c8`,`cgpa`) VALUES ('$name', '$rno', '$c1', '$c2', '$c3', '$c4', '$c5', '$c6', '$c7', '$c8','$cg')";
        $sql=mysqli_query($conn,$sql);
        
        if (!$sql) {
            echo '<script language="javascript">';
            echo 'alert("Invalid Details")';
            echo '</script>';
        }
        else{
            echo "<script>
               alert('Successful');
               window.location.href='add_cgpa.php';
               </script>";            
        }
    }
?>
