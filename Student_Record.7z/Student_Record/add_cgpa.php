<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./css/home.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="./css/font-awesome-4.7.0/css/font-awesome.css">
    <link rel="stylesheet" href="./css/form.css">
    <title>Add Cgpa</title>
</head>
<body>
        
    <div class="title">
        <a href="dashboard.php"><img src="./images/logo1.png" alt="" class="logo"></a>
        <span class="heading">Dashboard</span>
        <a href="logout.php" style="color: white"><span class="fa fa-sign-out fa-2x">Logout</span></a>
    </div>

    <div class="nav">
        <ul>
            <li class="dropdown" onclick="toggleDisplay('1')">
                <a href="" class="dropbtn">Classes &nbsp
                    <span class="fa fa-angle-down"></span>
                </a>
                <div class="dropdown-content" id="1">
                    <a href="add_classes.php">Add Class</a>
                    <a href="manage_classes.php">View Class</a>
                </div>
            </li>
            <li class="dropdown" onclick="toggleDisplay('2')">
                <a href="#" class="dropbtn">Students &nbsp
                    <span class="fa fa-angle-down"></span>
                </a>
                <div class="dropdown-content" id="2">
                    <a href="add_students.php">Add Students</a>
                    <a href="manage_students.php">View Students</a>
                </div>
            </li>
            <li class="dropdown" onclick="toggleDisplay('3')">
                <a href="#" class="dropbtn">Results &nbsp
                    <span class="fa fa-angle-down"></span>
                </a>
                <div class="dropdown-content" id="3">
                    <a href="add_cgpa.php">Add Results</a>
                    <a href="manage_cgpa.php">Manage Results</a>
                </div>
            </li>
            <li class="dropdown" onclick="toggleDisplay('3')">
                <a href="#" class="dropbtn">CGPA &nbsp
                    <span class="fa fa-angle-down"></span>
                </a>
                <div class="dropdown-content" id="3">
                    <a href="add_cgpa.php">Add CGPA</a>
                </div>
            </li>
        </ul>
    </div>

    <div class="main">
        <form action="pp.php" method="post">
            <fieldset>
            <legend>Enter CGPA</legend>
                <input type="text" name="name" id="" placeholder="Student Name">
                <input type="text" name="rno" placeholder="Roll No">
                <input type="text" name="c1" id="" placeholder="SEM 1">
                <input type="text" name="c2" id="" placeholder="SEM 2">
                <input type="text" name="c3" id="" placeholder="SEM 3">
                <input type="text" name="c4" id="" placeholder="SEM 4">
                <input type="text" name="c5" id="" placeholder="SEM 5">
                <input type="text" name="c6" id="" placeholder="SEM 6">
                <input type="text" name="c7" id="" placeholder="SEM 7">
                <input type="text" name="c8" id="" placeholder="SEM 8">
                
                <input type="submit" value="Submit">
            </fieldset>
        </form>
    </div>

</body>
</html>