<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="./css/homepage.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <title>CGPA Page</title>
</head>
<body>
    <div class="container">
        <div class="title">
            <span>Student Result Management System</span>
        </div>

         <div class="nav">
            <ul>
                <li>
                    <a href="index.html">Home</a>
                </li>   
                <li>
                    <a href="login.php">Login</a>
                </li>            
            </ul>
        </div>
        <div>  

            <form action="./fetch.php" method="get">
                <fieldset>
                    <legend class="heading">Student CGPA</legend>         
                    <input type="text" name="rn" placeholder="Roll No">
                    <input type="submit" value="Get Result">
                </fieldset>
            </form>
        </div>
    </div>
</body>
</html>